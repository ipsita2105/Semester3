struct stack{

    int data[5000];

    int top;

};

struct stack* newStack();

void stackPush(struct stack *s,int x);

int stackPop(struct stack *s);

int stackEmpty(struct stack *s);

int readFile(char *inFileName,char (*am)[500]);

void dfs(char (*am)[500],int root,int n);

void cutVertices(char (*am)[500],int n);

int IsCutVertex(char (*am)[500],int r,int n);
