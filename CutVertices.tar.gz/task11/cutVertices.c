#include <stdio.h>
#include <stdlib.h>

#include "header.h"


void cutVertices(char (*am)[500],int n){

int i,j;

int v,r;

int root;

char am_temp[500][500];

printf("Cut vertices are\n");

for(r=0;r<n;r++){


			//printf("Defined am_temp again\n");

			for(i=0;i<n;i++){
			
			
				for(j=0;j<n;j++){
			
				am_temp[i][j] = am[i][j];
			
				}
					
			
			}

		//printf("Called dfs for %d\n",r);
		
		//root = r;
		
		//printf("root before dfs = %d\n",root);

	 	//dfs(am_temp,root,n);
	 	
	 	//printf("Value of root after dfs = %d\n",root);
	 	
	 	dfs(am_temp,r,n);
	 	
	 	//printf("Value of r after dfs = %d\n",r);
	 
	 
		 if(IsCutVertex(am_temp,r,n)){
		 
		 printf("%d  ,",r);
		 
		 
		 }


}
	
	printf("\n");


}


void dfs(char (*am)[500],int root,int n){

int i,j;

int v;

int discovered[500];

int prev[500];

int nodeOrder[500];


   

    for(i=0;i<500;i++){

        discovered[i] = 0;
        prev[i] = -1;
        nodeOrder[i] = -1;

    }

int k1 =0;


struct stack *s = newStack();

stackPush(s,root);

	    while(!stackEmpty(s)){

	    v = stackPop(s);


		     if(discovered[v] != 1){

			nodeOrder[k1] = v;
			k1++;
		
			discovered[v] = 1;
			
			if(prev[v] != -1){ 
			am[v][prev[v]] = '2';
			am[prev[v]][v] = '2';
			}

				    for(i=0;i<n;i++){

					if(am[v][i] == '1'){
					
					prev[i] = v;			 

					stackPush(s,i);
	
					}

				    }

			}



	}
	
	//free(s);


}


int IsCutVertex(char (*am)[500],int r,int n){


int i;

int children = 0;

	for(i=0;i<n;i++){

		if(am[r][i] == '2'){

		children++;

		}

	}
	
	
	if(children > 1)
	return 1;
	
	else
	return 0;

}


int readFile(char *inFileName,char (*am)[500]){

    int i,j;

    int n;                /* Number of vertices*/

    char number[10], type[10];    /* Initial two lines od file*/

    FILE *amfile;

    amfile = fopen(inFileName,"r");    /* Opens file in read mode*/

    if(amfile == 0){

    printf("Error in opening file\n");

    }

    fscanf(amfile,"%s\n%s\n%d\n",number,type,&n);

    for(i=0;i<n;i++){

        for(j=0;j<n;j++){

            fscanf(amfile,"%c",&am[i][j]);    /* Scanning the matrix*/

        }

        fscanf(amfile,"\n");


    }

fclose(amfile);

return n;

}

