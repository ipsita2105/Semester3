#include <stdio.h>
#include <stdlib.h>

#include "header.h"



int main(){

char am[500][500];

char filename[20];

int n,root;


    printf("Enter input filename\n");
    scanf("%s",filename);

    n = readFile(filename,am);
   
    cutVertices(am,n);

}
