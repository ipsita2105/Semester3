#include<stdio.h>
#include<stdlib.h>


struct queue{

	int rear,front;          /* Keeps tack of rear and front*/
  
	//int size;		/*Keeps track of size*/

	int data[500];		/* Queue implemented as array*/
	
};

struct queue* newQueue();

void insert(struct queue *q,int v,int distance[]);

int getHighestPriority(struct queue *q);

int IsEmpty(struct queue *q);

void printQueue(struct queue *q);

void delete(struct queue *q,int v);

int readFile(char *inFileName,char (*am)[500]);

void dijkstra(char (*am)[500],int root,int goal,int n);

void generateDotFile(char (*am)[500],int array[],int n);

int main(){

char am[500][500];

char filename[20];

int n,root,goal;

	printf("Enter input filename\n");
	scanf("%s",filename);

	n = readFile(filename,am);
	
	printf("Enter value of root vertex\n");
	scanf("%d",&root);
	
	printf("Enter value of goal vertex\n");
	scanf("%d",&goal);
	
	dijkstra(am,root,goal,n);




}




void dijkstra(char (*am)[500],int root,int goal,int n){

int i;

int u;

int distance[n];

int prev[n];


struct queue *q = newQueue();

distance[root] = 0;

	for(i=0;i<n;i++){

		if(i != root){

		distance[i] = 100000;

		}

		prev[i] = -1;
		insert(q,i,distance);

	}

while(!IsEmpty(q)){

u = getHighestPriority(q);


	for(i=0;i<n;i++){

			if(am[u][i] !='0'){
			
				int weight = (int)am[u][i] - 48;


				if(distance[u] + weight < distance[i]){

				distance[i] = distance[u] + weight;
				prev[i] = u;
				delete(q,i);
				insert(q,i,distance);
				


				}


			}

		
	}


}

/*
int v = goal;								//This will print in reverse order

printf("The shortest path is (Printed in reverse order)-\n");

	while(prev[v] != -1){

		printf("%d ->",v );
		v = prev[v];
	}

printf("%d\n",root);

*/

int array[500];		// Array stores vertices name that are in path

int k =0;

int v = goal;

for(i=0;i<500;i++){

array[i] = -1;

}


	while(prev[v] != -1){

		array[k] = v;
		k++;
		v = prev[v];
	}

array[k] = root;

printf("The shortest path is-\n");

i=k;

for(i=k;i>=0;i--){

printf("%d ->",array[i]);

}


printf("\nLength of path %d\n",distance[goal]);

generateDotFile(am,array,n);

}


struct queue* newQueue(){

	struct queue *new = malloc(sizeof(struct queue));

	//new->size =10;             /* Initializing the queue*/
	new->rear = -1;
	new->front = -1;

	return new;

}



void insert(struct queue *q,int v,int distance[]){

int i,j;



		if( q->front == -1){

			q->front = q->rear = 0;             /* Adding first element */

			q->data[0] = v;

		}

		else{

			for(i=q->rear;i >= 0;i--){	
		
		
				if(distance[v] >= distance[q->data[i]]){
				
		
					for(j=(q->rear)+1;j>i+1;j--){
		
					q->data[j] = q->data[j-1];
					
		
					}
		
				q->data[i+1] = v;
				q->rear = (q->rear) +1;
				return;
		
		
				}
		
		
			}
		
		
			for(i=(q->rear)+1;i>0;i--){
		
				q->data[i] = q->data[i-1];
			
			}
			
			q->data[0] = v;
			q->rear = (q->rear) +1;
			

		}

}



int getHighestPriority(struct queue *q){

int x;
int i=0;




		if(q->front == q->rear){   
			
			
			x = q->data[q->front];
					
			q->front = q->rear =-1;
			
			return x;

		}

		else
		{
			x = q->data[q->front];
			
			for(i=0;i<q->rear;i++){
			
			q->data[i] = q->data[i+1];
			
			}
		
			q->rear = (q->rear) - 1;
			return x;

		}

}


void delete(struct queue *q,int v){

int i,j;

if(q->rear == q->front){

q->front = q->rear = -1;

}

for(i=0;i<= q->rear;i++){


	if(q->data[i] == v){

		for(j=i;j<q->rear;j++){

		q->data[j] = q->data[j+1];

		}


	}


}

q->rear = (q->rear) - 1;


}

int IsEmpty(struct queue *q){

		if( q-> front == -1){

			//printf("Queue is Empty !\n");	/* Returns if queue empty*/
			return 1;
		}

		else
			return 0;
			
}

void printQueue(struct queue *q){


int i=0;

printf("Queue is\n");

	for(i=0;i<=q->rear;i++){

	printf("%d ,",q->data[i]);


	}
	
	printf("\n");


}

int readFile(char *inFileName,char (*am)[500]){

	int i,j;

	int n;				/* Number of vertices*/

	char number[10], type[10];	/* Initial two lines od file*/

	FILE *amfile;

	amfile = fopen(inFileName,"r");	/* Opens file in read mode*/

	if(amfile == 0){

	printf("Error in opening file\n");

	}

	fscanf(amfile,"%s\n%s\n%d\n",number,type,&n);

	for(i=0;i<n;i++){

		for(j=0;j<n;j++){

			fscanf(amfile,"%c",&am[i][j]);	/* Scanning the matrix*/

		}

		fscanf(amfile,"\n");


	}

fclose(amfile);

return n;

}

void generateDotFile(char (*am)[500],int array[],int n){

char outFileName[20];

int i,j;

int k=1;

	printf("Enter out file name\n");
	scanf("%s",outFileName);
	
	// Generate Red Dot File
	
	FILE *reddotfile;
	
	reddotfile = fopen(outFileName,"w");
	
	fprintf(reddotfile,"graph {\n");

		for(i=0;i<n;i++){			// Check for each vertex in graph

			for(j=0;j<n;j++){
			
					int flag = 0;
			
			

				if(am[i][j] != '0' && (i<j)){		// See adjacent vertex
				
				
					for(k=1;k<500;k++){
				
						if( array[k] == i){
				
							if(array[k-1] == j || array[k+1] == j){
				
							fprintf(reddotfile,"%d -- %d[label = %c,color = red];\n",i,j,am[i][j]);
							flag =1;
				
							}
				
				
						}
				
				
					}
					
					if(array[0] == i && array[1] == j ){
				
					fprintf(reddotfile,"%d -- %d[label = %c,color = red];\n",i,j,am[i][j]);
					flag =1;
				
					}
					
					// If they are adjacent in array then print them red
					
					// Otherwise print non coloured edge

					else if(flag == 0){

						fprintf(reddotfile,"%d -- %d[label = %c];\n",i,j,am[i][j]);
				
					}
				
				}

			}

		

		}

fprintf(reddotfile,"}");
	
	
fclose(reddotfile);	



}


