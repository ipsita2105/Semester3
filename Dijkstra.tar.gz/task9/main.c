#include <stdio.h>
#include <stdlib.h>

#include "headerFile.h"


int main(){

char am[500][500];

char filename[20];

int n,root,goal;

	printf("Enter input filename\n");
	scanf("%s",filename);

	n = readFile(filename,am);
	
	printf("Enter value of root vertex\n");
	scanf("%d",&root);
	
	printf("Enter value of goal vertex\n");
	scanf("%d",&goal);
	
	dijkstra(am,root,goal,n);




}
