#include<stdio.h>
#include<stdlib.h>

#include "headerFile.h"

struct queue* newQueue(){

	struct queue *new = malloc(sizeof(struct queue));

	//new->size =10;             /* Initializing the queue*/
	new->rear = -1;
	new->front = -1;

	return new;

}



void insert(struct queue *q,int v,int distance[]){

int i,j;



		if( q->front == -1){

			q->front = q->rear = 0;             /* Adding first element */

			q->data[0] = v;

		}

		else{

			for(i=q->rear;i >= 0;i--){	
		
		
				if(distance[v] >= distance[q->data[i]]){
				
		
					for(j=(q->rear)+1;j>i+1;j--){
		
					q->data[j] = q->data[j-1];
					
		
					}
		
				q->data[i+1] = v;
				q->rear = (q->rear) +1;
				return;
		
		
				}
		
		
			}
		
		
			for(i=(q->rear)+1;i>0;i--){
		
				q->data[i] = q->data[i-1];
			
			}
			
			q->data[0] = v;
			q->rear = (q->rear) +1;
			

		}

}



int getHighestPriority(struct queue *q){

int x;
int i=0;




		if(q->front == q->rear){   
			
			
			x = q->data[q->front];
					
			q->front = q->rear =-1;
			
			return x;

		}

		else
		{
			x = q->data[q->front];
			
			for(i=0;i<q->rear;i++){
			
			q->data[i] = q->data[i+1];
			
			}
		
			q->rear = (q->rear) - 1;
			//q->data[q->rear] = -1;
			return x;

		}

}


void delete(struct queue *q,int v){

int i,j;

if(q->rear == q->front){

q->front = q->rear = -1;

}

for(i=0;i<= q->rear;i++){


	if(q->data[i] == v){

		for(j=i;j<q->rear;j++){

		q->data[j] = q->data[j+1];

		}


	}


}

q->rear = (q->rear) - 1;


}

int IsEmpty(struct queue *q){

		if( q-> front == -1){

			//printf("Queue is Empty !\n");	/* Returns if queue empty*/
			return 1;
		}

		else
			return 0;
			
}

void printQueue(struct queue *q){


int i=0;

printf("Queue is\n");

	for(i=0;i<=q->rear;i++){

	printf("%d ,",q->data[i]);


	}
	
	printf("\n");


}

