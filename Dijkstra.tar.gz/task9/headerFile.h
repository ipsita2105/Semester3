struct queue{

	int rear,front;          /* Keeps tack of rear and front*/
  
	//int size;		/*Keeps track of size*/

	int data[500];		/* Queue implemented as array*/
	
};

struct queue* newQueue();

void insert(struct queue *q,int v,int distance[]);

int getHighestPriority(struct queue *q);

int IsEmpty(struct queue *q);

void printQueue(struct queue *q);

void delete(struct queue *q,int v);

int readFile(char *inFileName,char (*am)[500]);

void dijkstra(char (*am)[500],int root,int goal,int n);

void generateDotFile(char (*am)[500],int array[],int n);

