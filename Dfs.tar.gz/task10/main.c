#include <stdio.h>
#include <stdlib.h>

#include "headerFile.h"


int main(){

char am[500][500];

char filename[20];

int n,root;


    printf("Enter input filename\n");
    scanf("%s",filename);

    n = readFile(filename,am);
   
    printf("Enter value of root vertex\n");
    scanf("%d",&root);
   
    dfs(am,root,n);

}
