#include <stdio.h>
#include <stdlib.h>

#include "headerFile.h"

struct stack* newStack(){


    struct stack *new = malloc(sizeof( struct stack));

    //new->size = 10;

    new -> top = -1;

    return new;

}


void stackPush(struct stack *s,int x){

        /*if(s->top == s->size){

        printf("Stack Full !\n");

        return;

        }*/

        if(s->top == -1){

        s->top =0;

        s->data[s->top] = x;

        }

        else{

        s->top = s->top+1;
        s->data[s->top] = x;
        }

}

int stackEmpty(struct stack *s){

    if(s->top == -1){
   
    return 1;
   
    }

    else{
    return 0;

    }

}

int stackPop(struct stack *s){

    /*if(s->top == -1){

    printf("Stack empty\n");

    }

    else{*/
    int x = s->data[s->top];
    s->top = s->top -1;

    return x;
    //}

}
