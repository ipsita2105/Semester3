struct stack{

    int data[500];

    int top;

    //int size;

};

struct stack* newStack();

void stackPush(struct stack *s,int x);

int stackPop(struct stack *s);

int stackEmpty(struct stack *s);

int readFile(char *inFileName,char (*am)[500]);

void dfs(char (*am)[500],int root,int n);

void generateDotFile(char (*am)[500],int n);

